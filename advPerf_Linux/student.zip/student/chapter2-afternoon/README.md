# 🔬 Advanced Linux Performance — Afternoon Labs

Welcome to the hands-on labs. Each lab drops a real problem on your machine.
You investigate with the tools you've learned, find the culprit, and submit the answer.

---

## Format

Every lab follows the same five steps:

| Step | Command | What happens |
|------|---------|--------------|
| 1 | `bash setup.sh` | Creates the problem on your machine |
| 2 | Read `PROBLEM.md` | Understand what you're investigating |
| 3 | **Investigate** | Use the tools — no peeking at the scripts! |
| 4 | `bash submit.sh <answer>` | Checks your answer |
| 5 | `bash cleanup.sh` | Resets the machine for the next lab |

---

## The Labs

| Lab | Topic | Key tools |
|-----|-------|-----------|
| `lab1-frozen-workers` | Process states & signals | `ps`, `/proc/<pid>/status`, `kill` |
| `lab2-cpu-vampire` | Intermittent CPU spikes | `pidstat -u 1`, `sar` |
| `lab3-memory-ghost` | Intermittent memory spikes | `vmstat 1`, `pidstat -r 1` |

---

## Tips

- Use **two terminals** — one to run investigative tools, one to read output
- All artefacts live under `/tmp/labX_*` — nothing permanent is changed
- The answer is always the **name of the culprit process** as shown by sysstat/ps
- Re-read `PROBLEM.md` when stuck — the hints are there
- Run `bash cleanup.sh` before moving to the next lab

---

## Tool quick-reference

```bash
# Process states
ps aux                          # all processes, STAT column = state
ps auxf                         # same, with tree view
cat /proc/<PID>/status          # kernel view: State, VmRSS, etc.
cat /proc/<PID>/wchan           # what kernel function it's waiting in

# CPU profiling (sysstat)
pidstat -u 1                    # per-process CPU every 1 second
sar -u 1 10                     # system-wide CPU, 10 samples

# Memory profiling (sysstat)
vmstat 1                        # system-wide memory every 1 second
pidstat -r 1                    # per-process RSS every 1 second
```

Install sysstat if needed:
```bash
sudo apt-get install -y sysstat
```
