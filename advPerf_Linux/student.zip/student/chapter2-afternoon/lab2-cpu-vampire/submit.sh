#!/bin/bash
# Lab 2 answer submission

ANSWER="$1"
EXPECTED="lab2-telemetry"

if [ -z "$ANSWER" ]; then
    echo ""
    echo "  Usage: bash submit.sh <process-name>"
    echo "  What is the name of the process consuming CPU?"
    echo ""
    exit 1
fi

if [ "$ANSWER" = "$EXPECTED" ]; then
    echo ""
    echo "  ✅  CORRECT — Lab 2 complete!"
    echo ""
    echo "  '$EXPECTED' was burning CPU in 10-second bursts every 35 seconds."
    echo "  Invisible to a casual 'top' glance — but 'pidstat -u 1' catches"
    echo "  every second and makes the pattern unmistakable."
    echo ""
    echo "  Run: bash cleanup.sh   — then move on to Lab 3."
    echo ""
else
    echo ""
    echo "  ❌  Incorrect. Keep investigating!"
    echo "  Hint: run 'pidstat -u 1 120 | tee /tmp/cpu_watch.log'"
    echo "  and wait for a spike. Check the Command column."
    echo ""
fi
