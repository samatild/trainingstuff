#!/bin/bash
# Lab 2 setup — CPU Vampire
set -e

LAB_DIR="$(cd "$(dirname "$0")" && pwd)"
STAGING="/tmp/lab2"

echo ""
echo "  ▶  Setting up Lab 2: CPU Vampire..."
echo ""

# Ensure sysstat is available
if ! command -v pidstat &>/dev/null; then
    echo "  Installing sysstat..."
    sudo apt-get install -y sysstat -q
fi

mkdir -p "$STAGING"
cp "$LAB_DIR/_cpu_hog.py" "$STAGING/svc.py"
rm -f /tmp/lab2_hog.pid

# Start the CPU hog with a disguised process name
(exec -a "lab2-telemetry" python3 "$STAGING/svc.py") \
    > /tmp/lab2_hog.out 2>&1 &
disown $!

echo "  Process started in background."
echo ""
echo "  ✅  Lab 2 is ready! Read PROBLEM.md to begin."
echo "  Note: the CPU spike occurs roughly every 35 seconds."
echo ""
