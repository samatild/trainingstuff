#!/bin/bash
# Lab 2 cleanup

echo ""
echo "  ▶  Cleaning up Lab 2..."

if [ -f /tmp/lab2_hog.pid ]; then
    pid=$(cat /tmp/lab2_hog.pid)
    kill -TERM "$pid" 2>/dev/null || true
    sleep 1
    kill -KILL "$pid" 2>/dev/null || true
fi

rm -f /tmp/lab2_hog.pid /tmp/lab2_hog.out /tmp/cpu_watch.log
rm -rf /tmp/lab2

echo "  ✅  Lab 2 cleaned up. Ready for Lab 3."
echo ""
