# 🔬 Lab 2 — The CPU Vampire

## How to run this lab

```bash
# 1. Start the lab (run once)
bash setup.sh

# 2. Read this file, then investigate
# 3. When you have the answer:
bash submit.sh <process-name>

# 4. Move to the next lab
bash cleanup.sh
```

> ⏱️ The CPU spike occurs roughly every **35 seconds**.
> Run your capture tools for at least **2 full minutes** to be sure to catch it.

---

## Situation

Users are reporting that this machine feels sluggish at random intervals.
A quick look at `top` shows CPU occasionally spikes — but by the time
you react, the CPU is back to idle. You can't catch the culprit.

There is **a process on this machine that burns CPU in short bursts**
and then goes quiet. It is designed to evade casual monitoring.

---

## Your Task

1. Identify the **process responsible** for the CPU spikes
2. Find its **process name** as shown in sysstat output
3. Submit: `bash submit.sh <process-name>`

---

## Key Insight

`top` refreshes every ~3 seconds by default.
A process that burns CPU for **10 seconds** then sleeps for **25 seconds**
is active only ~28% of the time — easy to miss if you're glancing manually.

`pidstat -u 1` samples **every second** and logs each process's CPU usage
continuously. Running it for a full minute will catch even short bursts.

---

## Approach

Install sysstat if needed:
```bash
sudo apt-get install -y sysstat
```

Capture CPU activity over a full cycle:
```bash
pidstat -u 1 120 | tee /tmp/cpu_watch.log
```

Wait for at least one spike to appear (~35 seconds), then press `Ctrl-C`
and search the output:
```bash
# Find any process with >50% CPU in the captured log
awk '$8 > 50' /tmp/cpu_watch.log
```

---

## What to look for

- A process with high `%CPU` appearing and disappearing in the pidstat output
- The **Command** column (last column) gives the process name
- The spike will last about 10 seconds before disappearing
