#!/usr/bin/env python3
"""
Lab 2 — CPU hog process.
Burns CPU at ~95% for 10 seconds, sleeps for 25 seconds, repeats.
Launched by setup.sh as: lab2-telemetry
"""
import time, os, signal, sys, ctypes

# Set the kernel thread name — this is what pidstat and ps -o comm show
ctypes.CDLL("libc.so.6").prctl(15, b"lab2-telemetry\x00", 0, 0, 0)


with open("/tmp/lab2_hog.pid", "w") as f:
    f.write(str(os.getpid()))


def handle_term(sig, frame):
    try:
        os.remove("/tmp/lab2_hog.pid")
    except FileNotFoundError:
        pass
    sys.exit(0)


signal.signal(signal.SIGTERM, handle_term)


def burn_cpu(seconds):
    """Tight loop to saturate one CPU core for the given duration."""
    end = time.monotonic() + seconds
    x = 0
    while time.monotonic() < end:
        x = (x * x + 1) % 999983   # arbitrary arithmetic, never yields


while True:
    burn_cpu(10)     # active:  10 seconds  (~95% CPU on one core)
    time.sleep(25)   # dormant: 25 seconds  (idle, invisible)
