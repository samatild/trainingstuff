#!/bin/bash
# Lab 1 cleanup

echo ""
echo "  ▶  Cleaning up Lab 1..."

# Workers in T state won't respond to SIGTERM — SIGCONT them first
for pid_file in /tmp/lab1_worker_*.pid; do
    [ -f "$pid_file" ] || continue
    pid=$(cat "$pid_file" 2>/dev/null) || continue
    kill -CONT "$pid" 2>/dev/null || true
    kill -TERM "$pid" 2>/dev/null || true
done

# Kill the saboteur
if [ -f /tmp/lab1_saboteur.pid ]; then
    pid=$(cat /tmp/lab1_saboteur.pid)
    kill -TERM "$pid" 2>/dev/null || true
fi

sleep 1

# Force-kill any stragglers
for pid_file in /tmp/lab1_worker_*.pid; do
    [ -f "$pid_file" ] || continue
    pid=$(cat "$pid_file" 2>/dev/null) || continue
    kill -KILL "$pid" 2>/dev/null || true
done
[ -f /tmp/lab1_saboteur.pid ] && \
    kill -KILL "$(cat /tmp/lab1_saboteur.pid)" 2>/dev/null || true

# Remove all artefacts
rm -f /tmp/lab1_worker_*.pid /tmp/lab1_worker_*.log \
      /tmp/lab1_worker_*.out /tmp/lab1_saboteur.pid \
      /tmp/lab1_saboteur.out
rm -rf /tmp/lab1

echo "  ✅  Lab 1 cleaned up. Ready for Lab 2."
echo ""
