#!/usr/bin/env python3
"""
Lab 1 — worker process.
Writes a heartbeat line to its log file every 3 seconds.
Launched by setup.sh as: lab1-worker-N
"""
import time, signal, sys, os, ctypes

worker_id = sys.argv[1] if len(sys.argv) > 1 else "0"
pid_file  = f"/tmp/lab1_worker_{worker_id}.pid"
log_file  = f"/tmp/lab1_worker_{worker_id}.log"

# Set kernel thread name so ps -o comm and /proc/pid/comm show the right name
name = f"lab1-worker-{worker_id}"
ctypes.CDLL("libc.so.6").prctl(15, name[:15].encode() + b"\x00", 0, 0, 0)


def handle_term(sig, frame):
    try:
        os.remove(pid_file)
    except FileNotFoundError:
        pass
    sys.exit(0)


signal.signal(signal.SIGTERM, handle_term)

with open(pid_file, "w") as f:
    f.write(str(os.getpid()))

counter = 0
while True:
    counter += 1
    with open(log_file, "a") as f:
        f.write(f"[worker-{worker_id}] processing batch {counter}\n")
    time.sleep(3)
