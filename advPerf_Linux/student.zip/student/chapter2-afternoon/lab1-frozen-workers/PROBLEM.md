# 🔬 Lab 1 — The Frozen Workers

## How to run this lab

```bash
# 1. Start the lab (run once)
bash setup.sh

# 2. Read this file, then investigate
# 3. When you have the answer:
bash submit.sh <process-name>

# 4. Move to the next lab
bash cleanup.sh
```

> ⏱️ Wait **~10 seconds** after `setup.sh` before investigating —
> the workers need time to produce some initial output.

---

## Situation

A data-processing service was started on this machine.
It runs **three worker processes** that are supposed to log a heartbeat
every few seconds to:

```
/tmp/lab1_worker_1.log
/tmp/lab1_worker_2.log
/tmp/lab1_worker_3.log
```

The logs have **stopped updating**. The workers show up in `ps` as running,
but they are producing no output. Something on this machine is interfering.

---

## Your Task

1. Find out **why** the workers are not running
2. Identify the **name of the process** responsible
3. Fix the situation *(optional — but satisfying)*
4. Submit: `bash submit.sh <process-name>`

---

## Hints

- Look at the **STAT** column in `ps aux` — what state are the workers in?
- `ps auxf` shows processes in a tree — look for anything suspicious
- `/proc/<PID>/status` shows the full kernel state of a process
- There is a process on this machine that should not be there

---

## Useful commands

```bash
# All processes with state
ps aux

# State of a specific PID
cat /proc/<PID>/status | grep State

# Full process tree
ps auxf

# All processes with PID, state, and name
ps -eo pid,ppid,stat,comm

# Send SIGCONT to a stopped process (if you find one)
kill -CONT <PID>
```
