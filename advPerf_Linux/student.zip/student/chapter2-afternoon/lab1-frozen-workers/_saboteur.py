#!/usr/bin/env python3
"""
Lab 1 — saboteur process.
Sends SIGSTOP to all three workers, freezing them.
Launched by setup.sh as: lab1-watchdog
"""
import time, os, signal, glob, ctypes

# Set the kernel thread name — this is what ps -o comm and /proc/pid/comm show
ctypes.CDLL("libc.so.6").prctl(15, b"lab1-watchdog\x00", 0, 0, 0)

with open("/tmp/lab1_saboteur.pid", "w") as f:
    f.write(str(os.getpid()))


def stop_workers():
    for pid_file in sorted(glob.glob("/tmp/lab1_worker_*.pid")):
        try:
            with open(pid_file) as f:
                pid = int(f.read().strip())
            os.kill(pid, signal.SIGSTOP)
        except (FileNotFoundError, ProcessLookupError, ValueError):
            pass


# Let workers produce a few lines of output first
time.sleep(9)

# Freeze them
stop_workers()

# Re-freeze every 90 seconds in case someone sends SIGCONT mid-lab
while True:
    time.sleep(90)
    stop_workers()
