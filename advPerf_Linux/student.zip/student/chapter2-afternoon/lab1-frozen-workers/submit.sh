#!/bin/bash
# Lab 1 answer submission

ANSWER="$1"
EXPECTED="lab1-watchdog"

if [ -z "$ANSWER" ]; then
    echo ""
    echo "  Usage: bash submit.sh <process-name>"
    echo "  What is the name of the process that froze the workers?"
    echo ""
    exit 1
fi

if [ "$ANSWER" = "$EXPECTED" ]; then
    echo ""
    echo "  ✅  CORRECT — Lab 1 complete!"
    echo ""
    echo "  '$EXPECTED' was periodically sending SIGSTOP to all three workers,"
    echo "  putting them into T (stopped) state."
    echo ""
    echo "  To fix it manually:"
    echo "    kill \$(cat /tmp/lab1_saboteur.pid)              # remove the saboteur"
    echo "    kill -CONT \$(cat /tmp/lab1_worker_*.pid)        # resume the workers"
    echo ""
    echo "  Run: bash cleanup.sh   — then move on to Lab 2."
    echo ""
else
    echo ""
    echo "  ❌  Not quite. Keep investigating!"
    echo "  Hint: check the STAT column in 'ps aux' for the worker processes."
    echo ""
fi
