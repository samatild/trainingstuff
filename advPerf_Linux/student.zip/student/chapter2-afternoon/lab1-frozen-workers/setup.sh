#!/bin/bash
# Lab 1 setup — Frozen Workers
set -e

LAB_DIR="$(cd "$(dirname "$0")" && pwd)"
STAGING="/tmp/lab1"

echo ""
echo "  ▶  Setting up Lab 1: Frozen Workers..."
echo ""

# Prepare staging area
mkdir -p "$STAGING"
cp "$LAB_DIR/_worker.py"   "$STAGING/worker.py"
cp "$LAB_DIR/_saboteur.py" "$STAGING/svc.py"

# Clean any leftover state from a previous run
rm -f /tmp/lab1_worker_*.pid /tmp/lab1_worker_*.log /tmp/lab1_saboteur.pid

# Start 3 workers with descriptive names
for i in 1 2 3; do
    (exec -a "lab1-worker-$i" python3 "$STAGING/worker.py" "$i") \
        > /tmp/lab1_worker_$i.out 2>&1 &
    disown $!
done

sleep 1

# Start the saboteur with a disguised name
(exec -a "lab1-watchdog" python3 "$STAGING/svc.py") \
    > /tmp/lab1_saboteur.out 2>&1 &
disown $!

echo "  Workers started. All components running."
echo ""
echo "  ✅  Lab 1 is ready!"
echo "  Wait about 10 seconds for the workers to produce output,"
echo "  then read PROBLEM.md and start investigating."
echo ""
