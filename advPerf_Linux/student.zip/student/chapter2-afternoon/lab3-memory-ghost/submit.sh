#!/bin/bash
# Lab 3 answer submission

ANSWER="$1"
EXPECTED="lab3-reporter"

if [ -z "$ANSWER" ]; then
    echo ""
    echo "  Usage: bash submit.sh <process-name>"
    echo "  What is the name of the process causing the memory spikes?"
    echo ""
    exit 1
fi

if [ "$ANSWER" = "$EXPECTED" ]; then
    echo ""
    echo "  ✅  CORRECT — Lab 3 complete!"
    echo ""
    echo "  '$EXPECTED' was allocating ~500 MB every 40–70 seconds,"
    echo "  holding it for 10 seconds, then releasing it — completely"
    echo "  invisible to a manual 'top' check."
    echo ""
    echo "  The key technique: run 'pidstat -r 1 | tee /tmp/pidstat_r.log'"
    echo "  continuously and grep for high RSS values after the fact."
    echo "  vmstat 1 lets you spot *when* to look."
    echo ""
    echo "  🎉  All three labs complete — well done!"
    echo ""
else
    echo ""
    echo "  ❌  Incorrect. Keep investigating!"
    echo "  Hint: run 'pidstat -r 1 | tee /tmp/pidstat_r.log' and wait."
    echo "  Search for lines where RSS (column 6) exceeds 400000 kB."
    echo ""
fi
