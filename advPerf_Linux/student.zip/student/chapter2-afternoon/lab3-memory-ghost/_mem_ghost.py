#!/usr/bin/env python3
"""
Lab 3 — memory ghost process.
Randomly allocates ~500 MB, touches every page (forces RSS), holds for 10 s,
releases, then waits 40–70 s before doing it again.
Launched by setup.sh as: lab3-reporter
"""
import time, os, signal, sys, random, ctypes

# Set the kernel thread name — this is what pidstat and ps -o comm show
ctypes.CDLL("libc.so.6").prctl(15, b"lab3-reporter\x00", 0, 0, 0)

with open("/tmp/lab3_ghost.pid", "w") as f:
    f.write(str(os.getpid()))


def handle_term(sig, frame):
    try:
        os.remove("/tmp/lab3_ghost.pid")
    except FileNotFoundError:
        pass
    sys.exit(0)


signal.signal(signal.SIGTERM, handle_term)

ALLOC_MB  = 500
PAGE_SIZE = 4096


def allocate_and_touch(mb):
    """Allocate mb megabytes and write one byte per page to force physical allocation."""
    size = mb * 1024 * 1024
    buf = bytearray(size)
    for i in range(0, size, PAGE_SIZE):
        buf[i] = 1
    return buf


while True:
    # Random quiet period between spikes
    wait_s = random.randint(40, 70)
    time.sleep(wait_s)

    # Allocate, touch all pages (RSS spikes), hold, then release
    buf = allocate_and_touch(ALLOC_MB)
    time.sleep(10)
    del buf          # RSS drops back to baseline
