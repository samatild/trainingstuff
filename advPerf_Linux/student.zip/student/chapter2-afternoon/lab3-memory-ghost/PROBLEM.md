# 🔬 Lab 3 — The Memory Ghost

## How to run this lab

```bash
# 1. Start the lab (run once)
bash setup.sh

# 2. Read this file, then investigate
# 3. When you have the answer:
bash submit.sh <process-name>

# 4. You're done!
bash cleanup.sh
```

> ⏱️ The memory spike occurs **randomly every 40–70 seconds**.
> Start your capture tools first, then be patient — wait at least **3 minutes**.

---

## Situation

The ops team has flagged that this machine occasionally runs low on available
memory, causing performance degradation. The issue is **intermittent** —
it appears, lasts a short while, and disappears.

You've checked `top` several times. Nothing stands out.
No process shows an abnormally high memory usage at the time of your checks.

There is **a process on this machine that randomly allocates a large chunk of
memory, holds it briefly, then releases it** — repeating on an irregular schedule.

---

## Your Task

1. Identify the **process responsible** for the memory spikes
2. Find its **process name** as shown by sysstat
3. Submit: `bash submit.sh <process-name>`

---

## Key Insight

`top` shows a **snapshot**. A process that allocates 500 MB for 10 seconds
then releases it is completely invisible if you happen to look between spikes.

The correct approach is **continuous recording**:

- `vmstat 1` shows system-wide free memory **every second**
- `pidstat -r 1` shows **per-process RSS every second**

By capturing both to files and reviewing after a spike, you can precisely
correlate the drop in free memory with a specific process.

---

## Approach

Install sysstat if needed:
```bash
sudo apt-get install -y sysstat
```

Open **two terminals** and run both captures simultaneously:

**Terminal 1** — system-wide memory:
```bash
vmstat 1 | tee /tmp/vmstat.log
```

**Terminal 2** — per-process memory:
```bash
pidstat -r 1 | tee /tmp/pidstat_r.log
```

Wait at least **2–3 minutes** for a spike to occur, then stop both captures
(`Ctrl-C`) and analyse the logs.

---

## Analysing the logs

```bash
# In vmstat output: column 4 is 'free' (kB)
# Look for lines where free memory dropped by ~500 MB (~512000 kB)
# The 'free' column is the 4th field after the header
grep -v "^[a-z]" /tmp/vmstat.log | awk '$4 < 5000000 {print NR, $0}'

# In pidstat -r output: column 6 is RSS (kB)
# Find any process with RSS above 400000 kB (400 MB)
awk '$6 > 400000' /tmp/pidstat_r.log
```

The **Command** column (last column in pidstat) is the process name you need.

---

## What to look for

| Log | Signal |
|-----|--------|
| `vmstat` | `free` column drops by ~500 000 kB and recovers ~10 seconds later |
| `pidstat -r` | A process RSS spikes to ~500 000 kB and then disappears |

Both events will be **time-aligned** — that alignment is your evidence.
