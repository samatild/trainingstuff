#!/bin/bash
# Lab 3 setup — Memory Ghost
set -e

LAB_DIR="$(cd "$(dirname "$0")" && pwd)"
STAGING="/tmp/lab3"

echo ""
echo "  ▶  Setting up Lab 3: Memory Ghost..."
echo ""

# Ensure sysstat is available
if ! command -v pidstat &>/dev/null; then
    echo "  Installing sysstat..."
    sudo apt-get install -y sysstat -q
fi

mkdir -p "$STAGING"
cp "$LAB_DIR/_mem_ghost.py" "$STAGING/svc.py"
rm -f /tmp/lab3_ghost.pid

# Start the memory ghost with a disguised process name
(exec -a "lab3-reporter" python3 "$STAGING/svc.py") \
    > /tmp/lab3_ghost.out 2>&1 &
disown $!

echo "  Memory ghost started in background."
echo ""
echo "  ✅  Lab 3 is ready! Read PROBLEM.md to begin."
echo "  Note: the memory spike occurs randomly every 40–70 seconds."
echo "        Start your captures and be patient."
echo ""
