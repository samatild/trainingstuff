#!/bin/bash
# Lab 3 cleanup

echo ""
echo "  ▶  Cleaning up Lab 3..."

if [ -f /tmp/lab3_ghost.pid ]; then
    pid=$(cat /tmp/lab3_ghost.pid)
    kill -TERM "$pid" 2>/dev/null || true
    sleep 1
    kill -KILL "$pid" 2>/dev/null || true
fi

rm -f /tmp/lab3_ghost.pid /tmp/lab3_ghost.out \
      /tmp/vmstat.log /tmp/pidstat_r.log
rm -rf /tmp/lab3

echo "  ✅  Lab 3 cleaned up."
echo ""
