# 🐧 Exercise 3 — Linux Signals

> *Send SIGTERM, SIGKILL, SIGSTOP, SIGUSR1/2, and SIGCHLD to real processes.*

---

1. If `SIGKILL` can't be caught or ignored, why **can't it kill a D-state process**?

2. We used `SIGUSR1` to trigger nginx log rotation. How does the log rotation tool know **which PID to send the signal to**?

3. What's the difference between **Ctrl-C** (`SIGINT`), **Ctrl-Z** (`SIGTSTP`), and **`SIGSTOP`**?  
   They all seem to pause or stop a process — are they the same thing?
