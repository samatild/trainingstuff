#!/usr/bin/env python3
"""
EX3 - Linux Process Signaling
==============================
Demonstrates signal delivery, custom handlers, ignoring, masking, and SIGCHLD.
"""
import os, sys, signal, subprocess, time
import tty, termios

# ── ANSI colours ──────────────────────────────────────────────────────────────
RESET   = "\033[0m"; BOLD  = "\033[1m"; DIM   = "\033[2m"
CYAN    = "\033[36m"; YELLOW = "\033[33m"; GREEN = "\033[32m"
RED     = "\033[31m"; MAGENTA = "\033[35m"; BLUE  = "\033[34m"
WHITE   = "\033[97m"

def c(color, text): return f"{color}{text}{RESET}"
SEP2 = c(BOLD + CYAN, "═" * 60)

def wait_space(prompt=""):
    print(f"\n  {c(BOLD+YELLOW,'▶')}  {c(YELLOW, prompt or 'Press SPACE to continue...')}", end="", flush=True)
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        while True:
            ch = sys.stdin.read(1)
            if ch == ' ': break
            if ch in ('\x03', '\x04', 'q'):
                print(c(RED, "\n\nAborted.")); sys.exit(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
    print()

def step_header(n, title):
    print(f"\n{SEP2}")
    print(f"  {c(BOLD+CYAN, f'STEP {n}')}  {c(WHITE+BOLD, title)}")
    print(SEP2)

def cmd_hint(*lines):
    print(f"\n  {c(BOLD+BLUE,'💡 Try in another terminal:')}")
    for l in lines: print(f"    {c(CYAN, l)}")

def read_state(pid):
    try:
        for line in open(f"/proc/{pid}/status"):
            if line.startswith("State:"): return line.split(":")[1].strip()
    except: return "gone"
    return "?"

def send_signal(pid, sig):
    name = signal.Signals(sig).name
    print(f"\n  {c(BOLD+RED, f'→ Sending {name} ({sig})')}  to PID {c(MAGENTA, str(pid))}")
    os.kill(pid, sig)

def cleanup(worker):
    try: worker.terminate(); worker.wait(timeout=3)
    except Exception:
        try: worker.kill()
        except: pass

# Worker scripts written to temp files so subprocess can exec them cleanly
WORKER_DIR = "/tmp/ex3_workers"
os.makedirs(WORKER_DIR, exist_ok=True)

def write_worker(name, code):
    path = f"{WORKER_DIR}/{name}.py"
    with open(path, 'w') as f:
        f.write(code)
    return path

# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{SEP2}")
print(f"  {c(BOLD+WHITE, 'EX3 — Linux Process Signaling')}")
print(f"  {c(DIM, 'SIGTERM  SIGKILL  SIGSTOP/CONT  SIGUSR1/2  SIGCHLD')}")
print(SEP2)
print(f"""
  {c(DIM,'A signal is an asynchronous notification sent to a process.')}
  {c(DIM,'The kernel delivers it — the process can catch, ignore, or die.')}
""")
cmd_hint(f"kill -l   # list all signals")
wait_space("Press SPACE to start")

# ══════════════════════════════════════════════════════════════════════════════
# STEP 1 — SIGTERM: graceful shutdown (catchable)
# ══════════════════════════════════════════════════════════════════════════════
step_header(1, "SIGTERM (15) — Graceful Shutdown")
print(f"""
  {c(BOLD,'Key facts:')}
  {c(DIM,'  • Default signal sent by:  kill <pid>  and  systemctl stop')}
  {c(DIM,'  • CAN be caught — process can run cleanup before exiting')}
  {c(DIM,'  • CAN be ignored — process stays alive')}
  {c(DIM,'  • Well-behaved daemons install a SIGTERM handler')}
""")

w1 = write_worker("sigterm", """
import signal, sys, time, os

def handler(sig, frame):
    print(f'[WORKER] Caught SIGTERM — cleaning up and exiting gracefully', flush=True)
    sys.exit(0)

signal.signal(signal.SIGTERM, handler)
print(f'[WORKER] PID {os.getpid()} running — SIGTERM handler installed', flush=True)
while True:
    time.sleep(0.1)
""")

worker = subprocess.Popen(['python3', w1],
                          stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                          text=True, bufsize=1)
line = worker.stdout.readline().strip()
print(f"\n  {c(GREEN,'●')}  {line}")
print(f"  {c(DIM,'State:')}  {c(CYAN, read_state(worker.pid))}")
cmd_hint(
    f"cat /proc/{worker.pid}/status | grep SigCgt   # caught signal bitmask",
)
wait_space("Press SPACE to send SIGTERM — watch it catch and exit cleanly")

send_signal(worker.pid, signal.SIGTERM)
time.sleep(0.3)
out = worker.stdout.read().strip()
print(f"  {c(YELLOW,'Worker said:')}  {c(BOLD, out)}")
worker.wait()
print(f"  {c(GREEN,'✔')}  Exit code: {c(BOLD, str(worker.returncode))}  (0 = clean exit from handler)")
wait_space("Press SPACE for SIGKILL")

# ══════════════════════════════════════════════════════════════════════════════
# STEP 2 — SIGKILL: forced, uncatchable
# ══════════════════════════════════════════════════════════════════════════════
step_header(2, "SIGKILL (9) — Forced Termination")
print(f"""
  {c(BOLD,'Key facts:')}
  {c(DIM,'  • Delivered and enforced DIRECTLY by the kernel')}
  {c(DIM,'  • CANNOT be caught, blocked, or ignored — ever')}
  {c(DIM,'  • Process has zero chance to clean up')}
  {c(DIM,'  • Does NOT work on D-state processes (hardware wait)')}
""")

w2 = write_worker("sigkill", """
import signal, time, os
signal.signal(signal.SIGTERM, signal.SIG_IGN)   # ignore SIGTERM
print(f'[WORKER] PID {os.getpid()} — ignoring SIGTERM, only SIGKILL stops me', flush=True)
while True:
    time.sleep(0.1)
""")

worker = subprocess.Popen(['python3', w2],
                          stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                          text=True, bufsize=1)
line = worker.stdout.readline().strip()
print(f"\n  {c(GREEN,'●')}  {line}")

wait_space("Press SPACE to try SIGTERM first (it is ignored)")
send_signal(worker.pid, signal.SIGTERM)
time.sleep(0.3)
state = read_state(worker.pid)
print(f"  {c(BOLD+YELLOW,'Still alive!')}  State: {c(MAGENTA, state)}  (SIGTERM was ignored)")

wait_space("Press SPACE to send SIGKILL — no escape")
send_signal(worker.pid, signal.SIGKILL)
time.sleep(0.2)
worker.wait()
print(f"  {c(GREEN,'✔')}  Exit code: {c(BOLD, str(worker.returncode))}  "
      f"{c(DIM,'(negative = killed by signal, -9 = SIGKILL)')}")
wait_space("Press SPACE for SIGSTOP / SIGCONT")

# ══════════════════════════════════════════════════════════════════════════════
# STEP 3 — SIGSTOP / SIGCONT: pause and resume
# ══════════════════════════════════════════════════════════════════════════════
step_header(3, "SIGSTOP (19) / SIGCONT (18) — Pause and Resume")
print(f"""
  {c(BOLD,'Key facts:')}
  {c(DIM,'  • SIGSTOP: freezes the process completely — like hitting pause')}
  {c(DIM,'  • SIGCONT: resumes it exactly where it stopped')}
  {c(DIM,'  • Both CANNOT be caught or ignored (just like SIGKILL)')}
  {c(DIM,'  • Ctrl-Z in a shell sends SIGTSTP — the catchable version')}
  {c(DIM,'  • Used by: gdb, strace, shell job control, cgroups freezer')}
""")

w3 = write_worker("stopcont", """
import time, os
i = 0
while True:
    print(f'[WORKER] tick {i}', flush=True)
    i += 1
    time.sleep(0.3)
""")

worker = subprocess.Popen(['python3', w3],
                          stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                          text=True, bufsize=1)
time.sleep(0.5)
ticks = [worker.stdout.readline().strip() for _ in range(3)]
print(f"\n  {c(GREEN,'●')}  Worker ticking:  {c(CYAN, '  '.join(ticks))}")
print(f"  {c(DIM,'State:')}  {c(GREEN, read_state(worker.pid))}")

wait_space("Press SPACE to SIGSTOP the worker")
send_signal(worker.pid, signal.SIGSTOP)
time.sleep(0.1)
print(f"  {c(DIM,'State:')}  {c(BOLD+YELLOW, read_state(worker.pid))}  (frozen)")
cmd_hint(f"ps -o pid,stat,comm -p {worker.pid}")

wait_space("Press SPACE to SIGCONT — worker resumes from exactly where it froze")
send_signal(worker.pid, signal.SIGCONT)
time.sleep(0.7)
ticks_after = [worker.stdout.readline().strip() for _ in range(3)]
print(f"  {c(DIM,'State:')}  {c(BOLD+CYAN, read_state(worker.pid))}  (running again)")
print(f"  {c(GREEN,'●')}  Ticks resumed:   {c(CYAN, '  '.join(ticks_after))}")
cleanup(worker)
wait_space("Press SPACE for SIGUSR1 / SIGUSR2")

# ══════════════════════════════════════════════════════════════════════════════
# STEP 4 — SIGUSR1 / SIGUSR2: application-defined signals
# ══════════════════════════════════════════════════════════════════════════════
step_header(4, "SIGUSR1 (10) / SIGUSR2 (12) — Application-Defined Signals")
print(f"""
  {c(BOLD,'Key facts:')}
  {c(DIM,'  • Reserved for application use — no kernel-defined meaning')}
  {c(DIM,'  • Default action is terminate, but apps install custom handlers')}
  {c(DIM,'  • Real-world uses:')}
  {c(DIM,'      nginx SIGUSR1  → reopen log files (log rotation)')}
  {c(DIM,'      nginx SIGUSR2  → graceful upgrade to new binary')}
  {c(DIM,'      Java  SIGUSR1  → thread dump to stdout')}
""")

w4 = write_worker("sigusr", """
import signal, os, time

def on_usr1(sig, frame):
    print('[WORKER] USR1 → reloading config (simulated)', flush=True)

def on_usr2(sig, frame):
    print('[WORKER] USR2 → stats dump:', flush=True)
    print('[WORKER]   uptime=42s  connections=1337  errors=0', flush=True)

signal.signal(signal.SIGUSR1, on_usr1)
signal.signal(signal.SIGUSR2, on_usr2)
print(f'[WORKER] PID {os.getpid()} — USR1=reload  USR2=stats', flush=True)
while True:
    time.sleep(0.1)
""")

worker = subprocess.Popen(['python3', w4],
                          stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                          text=True, bufsize=1)
line = worker.stdout.readline().strip()
print(f"\n  {c(GREEN,'●')}  {line}")
print(f"  {c(DIM,'State:')}  {c(CYAN, read_state(worker.pid))}")

wait_space("Press SPACE to send SIGUSR1 (config reload)")
send_signal(worker.pid, signal.SIGUSR1)
time.sleep(0.2)
print(f"  {c(YELLOW,'Worker:')}  {c(BOLD, worker.stdout.readline().strip())}")

wait_space("Press SPACE to send SIGUSR2 (stats dump)")
send_signal(worker.pid, signal.SIGUSR2)
time.sleep(0.2)
for _ in range(2):
    line = worker.stdout.readline().strip()
    if line: print(f"  {c(YELLOW,'Worker:')}  {c(BOLD, line)}")
cleanup(worker)
wait_space("Press SPACE for SIGCHLD")

# ══════════════════════════════════════════════════════════════════════════════
# STEP 5 — SIGCHLD: child state notification
# ══════════════════════════════════════════════════════════════════════════════
step_header(5, "SIGCHLD (17) — Child State Change")
print(f"""
  {c(BOLD,'Key facts:')}
  {c(DIM,'  • Kernel sends SIGCHLD to the PARENT whenever a child:')}
  {c(DIM,'      exits,  is stopped (SIGSTOP),  or resumed (SIGCONT)')}
  {c(DIM,'  • Default action: ignore (but zombie is still created!)')}
  {c(DIM,'  • Production daemons install a SIGCHLD handler to call waitpid()')}
  {c(DIM,'    asynchronously — no polling, no blocking')}
""")

# Coordination pipes: parent writes to go_w to release each child
go_r, go_w = os.pipe()
chld_events = []

def sigchld_handler(sig, frame):
    # Reap any exited child and record the event
    while True:
        try:
            pid, status = os.waitpid(-1, os.WNOHANG)
            if pid == 0:
                break
            chld_events.append(
                f"SIGCHLD → reaped PID {pid}, exit code {os.WEXITSTATUS(status)}"
            )
        except ChildProcessError:
            break

signal.signal(signal.SIGCHLD, sigchld_handler)
print(f"  {c(DIM,'SIGCHLD handler installed on parent PID')}  {c(MAGENTA, str(os.getpid()))}")

# Fork 3 children — each waits on go_r, then exits after a staggered delay
child_pids = []
for i in range(3):
    pid = os.fork()
    if pid == 0:
        os.close(go_w)              # child only reads
        os.read(go_r, 1)            # block until parent sends go
        os.close(go_r)
        time.sleep(i * 0.3)         # stagger: child 0 exits first, then 1, then 2
        os._exit(i)
    child_pids.append(pid)

os.close(go_r)   # parent only writes

print(f"  {c(DIM,'Forked children:')}  {c(MAGENTA, str(child_pids))}")
cmd_hint(
    f"ps -o pid,ppid,stat,comm --ppid {os.getpid()}",
)
wait_space("Children are waiting. Press SPACE — they will exit and trigger SIGCHLD each time")

# Release all children at once — they stagger their exits via sleep
os.write(go_w, b'\x01' * len(child_pids))
os.close(go_w)

# Wait long enough for all children to exit (longest is 2 * 0.3 = 0.6s)
time.sleep(1.0)

print(f"\n  {c(GREEN,'✔')}  SIGCHLD events received ({c(BOLD, str(len(chld_events)))} total):")
for ev in chld_events:
    print(f"    {c(CYAN, ev)}")
if not chld_events:
    print(f"    {c(YELLOW,'(signals coalesced — common when children exit simultaneously)')}")
    print(f"    {c(DIM,'That is why the handler always loops waitpid() until WNOHANG returns 0')}")

wait_space("Press SPACE for summary")

# ══════════════════════════════════════════════════════════════════════════════
# Reset SIGCHLD to default so summary fork works cleanly
signal.signal(signal.SIGCHLD, signal.SIG_DFL)
import subprocess; subprocess.run(['rm', '-rf', WORKER_DIR])

print(f"\n{SEP2}")
print(f"  {c(BOLD+GREEN,'DONE')}  — Signal summary")
print(SEP2)
sigs = [
    ("SIGTERM  (15)", CYAN,   "Graceful shutdown   — catchable, ignorable"),
    ("SIGKILL  ( 9)", RED,    "Forced kill         — cannot be caught, blocked, or ignored"),
    ("SIGSTOP  (19)", YELLOW, "Freeze process      — cannot be caught or ignored"),
    ("SIGCONT  (18)", GREEN,  "Resume stopped proc — cannot be caught or ignored"),
    ("SIGUSR1  (10)", MAGENTA,"App-defined         — reload / custom action"),
    ("SIGUSR2  (12)", MAGENTA,"App-defined         — stats / custom action"),
    ("SIGCHLD  (17)", CYAN,   "Child exited/stopped — enables async child reaping"),
]
for name, col, desc in sigs:
    print(f"  {c(BOLD+col, name)}   {c(DIM, desc)}")
print(f"{SEP2}\n")
