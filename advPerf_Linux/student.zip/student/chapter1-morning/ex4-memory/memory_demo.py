#!/usr/bin/env python3
"""
EX4 - Virtual Memory, Physical Memory, and Swap
=================================================
Demonstrates how a process's memory is split between:
  • Virtual address space  (VmSize)  — what the process reserved
  • Physical RAM           (VmRSS)   — pages actually in memory
  • Swap                   (VmSwap)  — pages evicted to disk
"""
import os, sys, mmap, time
import tty, termios

# ── ANSI colours ──────────────────────────────────────────────────────────────
RESET   = "\033[0m"; BOLD  = "\033[1m"; DIM   = "\033[2m"
CYAN    = "\033[36m"; YELLOW = "\033[33m"; GREEN = "\033[32m"
RED     = "\033[31m"; MAGENTA = "\033[35m"; BLUE  = "\033[34m"
WHITE   = "\033[97m"; ORANGE = "\033[38;5;214m"

def c(color, text): return f"{color}{text}{RESET}"
SEP2 = c(BOLD + CYAN, "═" * 64)

def wait_space(prompt=""):
    print(f"\n  {c(BOLD+YELLOW,'▶')}  {c(YELLOW, prompt or 'Press SPACE to continue...')}", end="", flush=True)
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        while True:
            ch = sys.stdin.read(1)
            if ch == ' ': break
            if ch in ('\x03', '\x04', 'q'):
                print(c(RED, "\n\nAborted.")); sys.exit(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
    print()

def step_header(n, title):
    print(f"\n{SEP2}")
    print(f"  {c(BOLD+CYAN, f'STEP {n}')}  {c(WHITE+BOLD, title)}")
    print(SEP2)

def cmd_hint(*lines):
    print(f"\n  {c(BOLD+BLUE,'💡 Try in another terminal:')}")
    for l in lines: print(f"    {c(CYAN, l)}")

def kb_to_mb(kb_str):
    """Parse '123456 kB' → float MB"""
    try: return int(kb_str.split()[0]) / 1024
    except: return 0.0

def read_proc_status(pid):
    fields = {}
    try:
        with open(f"/proc/{pid}/status") as f:
            for line in f:
                if ':' in line:
                    k, v = line.split(':', 1)
                    fields[k.strip()] = v.strip()
    except: pass
    return fields

def read_meminfo():
    fields = {}
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if ':' in line:
                    k, v = line.split(':', 1)
                    fields[k.strip()] = v.strip()
    except: pass
    return fields

def bar(used_mb, total_mb, width=32, color=GREEN):
    """Render a simple ASCII progress bar."""
    if total_mb == 0: return "N/A"
    filled = int(width * used_mb / total_mb)
    filled = max(0, min(filled, width))
    bar_str = "█" * filled + "░" * (width - filled)
    return f"{c(color, bar_str)}  {used_mb:6.0f} / {total_mb:.0f} MB"

def show_memory(worker_pid, label=""):
    if label:
        print(f"\n  {c(BOLD+WHITE, label)}")

    ws  = read_proc_status(worker_pid)
    mi  = read_meminfo()

    vmsize_mb = kb_to_mb(ws.get('VmSize', '0 kB'))
    vmrss_mb  = kb_to_mb(ws.get('VmRSS',  '0 kB'))
    vmswap_mb = kb_to_mb(ws.get('VmSwap', '0 kB'))

    mem_total_mb  = kb_to_mb(mi.get('MemTotal',  '0 kB'))
    mem_avail_mb  = kb_to_mb(mi.get('MemAvailable', '0 kB'))
    swap_total_mb = kb_to_mb(mi.get('SwapTotal', '0 kB'))
    swap_free_mb  = kb_to_mb(mi.get('SwapFree',  '0 kB'))
    swap_used_mb  = swap_total_mb - swap_free_mb

    # ── process view ──────────────────────────────────────────────────────────
    print(f"\n  {c(DIM, f'── Worker PID {worker_pid} ──────────────────────────────')}")
    print(f"  {c(DIM,'VmSize (virtual address space):')}  "
          f"{c(BOLD+CYAN,    f'{vmsize_mb:7.1f} MB')}  "
          f"{c(DIM, '← address space reserved (no RAM used yet for untouched pages)')}")
    print(f"  {c(DIM,'VmRSS  (resident / physical):  ')}  "
          f"{c(BOLD+GREEN,   f'{vmrss_mb:7.1f} MB')}  "
          f"{c(DIM, '← pages actually in physical RAM')}")
    print(f"  {c(DIM,'VmSwap (evicted to swap):       ')}  "
          f"{c(BOLD+ORANGE if vmswap_mb > 0 else BOLD+DIM,  f'{vmswap_mb:7.1f} MB')}  "
          f"{c(DIM, '← pages moved to disk by the kernel')}")

    # visual bars
    print(f"\n  {c(DIM,'Physical RAM used by worker:')}  {bar(vmrss_mb,  mem_total_mb,  width=28, color=GREEN)}")
    if vmswap_mb > 0:
        print(f"  {c(DIM,'Swap used by worker:        ')}  {bar(vmswap_mb, swap_total_mb, width=28, color=ORANGE)}")

    # ── system view ───────────────────────────────────────────────────────────
    print(f"\n  {c(DIM, '── System ───────────────────────────────────────────')}")
    print(f"  {c(DIM,'MemAvailable:')}  {bar(mem_total_mb - mem_avail_mb, mem_total_mb, width=28, color=CYAN)}")
    print(f"  {c(DIM,'Swap used:   ')}  {bar(swap_used_mb, swap_total_mb, width=28, color=RED if swap_used_mb > 100 else YELLOW)}")

def show_smaps_rollup(worker_pid):
    try:
        with open(f"/proc/{worker_pid}/smaps_rollup") as f:
            lines = f.readlines()
        print(f"\n  {c(DIM, f'/proc/{worker_pid}/smaps_rollup  (summary of all mappings):')}")
        for line in lines[1:]:   # skip the header address line
            key, _, val = line.partition(':')
            key = key.strip(); val = val.strip()
            if key in ('Rss', 'Pss', 'Shared_Clean', 'Private_Dirty', 'Swap'):
                mb = kb_to_mb(val)
                highlight = BOLD+GREEN if key == 'Rss' else BOLD+ORANGE if key == 'Swap' else DIM
                print(f"    {c(DIM, f'{key:<16}')}  {c(highlight, f'{mb:7.1f} MB')}")
    except Exception as e:
        print(c(DIM, f"    (smaps_rollup: {e})"))

def progress(current_mb, total_mb, width=40):
    pct = current_mb / total_mb
    filled = int(width * pct)
    sys.stdout.write(f"\r  {c(DIM,'Touching pages:')}  "
                     f"{c(GREEN, '█' * filled)}{c(DIM, '░' * (width - filled))}  "
                     f"{c(BOLD, f'{current_mb:.0f}')}/{total_mb:.0f} MB   ")
    sys.stdout.flush()

# ══════════════════════════════════════════════════════════════════════════════
# Check swap is available
# ══════════════════════════════════════════════════════════════════════════════
mi = read_meminfo()
swap_total = kb_to_mb(mi.get('SwapTotal', '0 kB'))

print(f"\n{SEP2}")
print(f"  {c(BOLD+WHITE, 'EX4 — Virtual Memory, Physical Memory, and Swap')}")
print(SEP2)
ram_total_mb  = kb_to_mb(mi.get('MemTotal',     '0 kB'))
ram_avail_mb  = kb_to_mb(mi.get('MemAvailable', '0 kB'))
print(f"\n  {c(DIM,'RAM total:  ')}  {c(BOLD, f'{ram_total_mb:.0f} MB')}")
print(f"  {c(DIM,'Available:  ')}  {c(BOLD, f'{ram_avail_mb:.0f} MB')}")
print(f"  {c(DIM,'Swap total: ')}  {c(BOLD+GREEN if swap_total > 0 else BOLD+RED, f'{swap_total:.0f} MB')}")
if swap_total == 0:
    print(c(RED, "\n  ⚠  No swap! Run: sudo swapon /swapfile"))
    sys.exit(1)

# ══════════════════════════════════════════════════════════════════════════════
# Coordination pipes (same pattern as EX1)
# ══════════════════════════════════════════════════════════════════════════════
child_done_r, child_done_w = os.pipe()
parent_go_r,  parent_go_w  = os.pipe()

# Allocation sizes
VIRTUAL_MB  = 700
PHYSICAL_MB = 250   # stage 2: touch this much
SWAP_MB     = 450   # stage 3: touch this much more (total 700 MB > available RAM)
PAGE        = 4096

wait_space("Ready? Press SPACE to start")

worker_pid = os.fork()

# ══════════════════════════════════════════════════════════════════════════════
if worker_pid == 0:
    # ── WORKER — never calls wait_space(), never touches the terminal ─────────
    os.close(child_done_r)
    os.close(parent_go_w)

    # Stage 1: reserve virtual address space, touch nothing
    m = mmap.mmap(-1, VIRTUAL_MB * 1024 * 1024)

    os.write(child_done_w, b'\x01')   # checkpoint 1: virtual allocated
    os.read(parent_go_r, 1)           # wait for parent

    # Stage 2: touch PHYSICAL_MB — bring pages into RAM
    PHYSICAL_BYTES = PHYSICAL_MB * 1024 * 1024
    for i in range(0, PHYSICAL_BYTES, PAGE):
        m[i] = 0x42
        if i % (10 * 1024 * 1024) == 0:
            os.write(child_done_w, b'\xAA')  # progress tick every 10 MB

    os.write(child_done_w, b'\x02')   # checkpoint 2: physical done
    os.read(parent_go_r, 1)           # wait for parent

    # Stage 3: touch remaining pages — force swap
    TOTAL_BYTES = VIRTUAL_MB * 1024 * 1024
    for i in range(PHYSICAL_BYTES, TOTAL_BYTES, PAGE):
        m[i] = 0x43
        if i % (10 * 1024 * 1024) == 0:
            os.write(child_done_w, b'\xBB')  # progress tick every 10 MB

    os.write(child_done_w, b'\x03')   # checkpoint 3: all touched (swap engaged)
    os.read(parent_go_r, 1)           # wait for parent

    # Cleanup
    m.close()
    os.close(child_done_w)
    os.close(parent_go_r)
    sys.exit(0)

else:
    # ── PARENT — controls the terminal and narration ──────────────────────────
    os.close(child_done_w)
    os.close(parent_go_r)

    # ══════════════════════════════════════════════════════════════════════════
    # STEP 1 — Virtual allocation
    # ══════════════════════════════════════════════════════════════════════════
    os.read(child_done_r, 1)   # wait for checkpoint 1

    step_header(1, f"Virtual Allocation — mmap({VIRTUAL_MB} MB) without touching")
    print(f"""
  {c(BOLD,'What happened:')}
  {c(DIM,f'  • Worker called mmap(-1, {VIRTUAL_MB} MB)  — anonymous private mapping')}
  {c(DIM,'  • The kernel updated the process page table — no physical pages allocated')}
  {c(DIM,'  • VmSize jumps by 700 MB,  VmRSS barely changes')}
  {c(DIM,'  • Cost: nearly zero — just a few page table entries')}
""")
    show_memory(worker_pid, "Memory snapshot after mmap (no touch):")
    cmd_hint(
        f"cat /proc/{worker_pid}/status | grep -E 'VmSize|VmRSS|VmSwap'",
        f"cat /proc/{worker_pid}/smaps_rollup",
        f"cat /proc/{worker_pid}/maps | grep -c ''   # count mapped regions",
    )
    wait_space(f"VmSize is huge, VmRSS is tiny. Press SPACE to fault in {PHYSICAL_MB} MB of pages")
    os.write(parent_go_w, b'\x01')

    # ══════════════════════════════════════════════════════════════════════════
    # STEP 2 — Physical memory (page faults)
    # ══════════════════════════════════════════════════════════════════════════
    step_header(2, f"Physical Memory — touching {PHYSICAL_MB} MB (page faults)")
    print(f"""
  {c(BOLD,'What is happening:')}
  {c(DIM,'  • Worker writes one byte per page (every 4096 bytes)')}
  {c(DIM,'  • Each write hits a not-present page → CPU raises a page fault')}
  {c(DIM,'  • Kernel handles the fault: allocates a physical frame, zeros it,')}
  {c(DIM,'    maps it into the process page table, resumes execution')}
  {c(DIM,'  • VmRSS grows by 4 kB per fault  (one physical page per fault)')}
""")

    # Drain progress ticks and show live progress
    touched_mb = 0
    while True:
        byte = os.read(child_done_r, 1)
        if byte == b'\x02':   # checkpoint done
            break
        # progress tick (every 10 MB)
        touched_mb += 10
        progress(touched_mb, PHYSICAL_MB)
    print()   # newline after progress bar

    show_memory(worker_pid, "Memory snapshot after touching 250 MB:")
    show_smaps_rollup(worker_pid)
    cmd_hint(
        f"cat /proc/{worker_pid}/status | grep -E 'VmSize|VmRSS|VmSwap'",
        f"grep -E 'Rss|Pss|Swap' /proc/{worker_pid}/smaps_rollup",
    )
    wait_space(f"RSS grew, VmSwap = 0. Press SPACE to touch the remaining {SWAP_MB} MB and force swap")
    os.write(parent_go_w, b'\x02')

    # ══════════════════════════════════════════════════════════════════════════
    # STEP 3 — Swap pressure
    # ══════════════════════════════════════════════════════════════════════════
    step_header(3, f"Swap Pressure — touching {SWAP_MB} MB more (total {VIRTUAL_MB} MB)")
    print(f"""
  {c(BOLD,'What is happening:')}
  {c(DIM,f'  • Worker is now touching {SWAP_MB} MB more — total {VIRTUAL_MB} MB')}
  {c(DIM,f'  • Available RAM is < {VIRTUAL_MB} MB → kernel must reclaim pages')}
  {c(DIM,'  • kswapd wakes up, scans LRU lists, picks least-recently-used pages')}
  {c(DIM,'  • Those pages are compressed / written to /swapfile')}
  {c(DIM,'  • VmRSS stops growing (capped by available RAM)')}
  {c(DIM,'  • VmSwap grows (evicted pages tracked here)')}
""")

    # Drain progress ticks
    touched_mb = 0
    while True:
        byte = os.read(child_done_r, 1)
        if byte == b'\x03':   # checkpoint done
            break
        touched_mb += 10
        progress(touched_mb, SWAP_MB)
    print()

    show_memory(worker_pid, "Memory snapshot after touching all 700 MB:")
    show_smaps_rollup(worker_pid)
    cmd_hint(
        f"cat /proc/{worker_pid}/status | grep -E 'VmSize|VmRSS|VmSwap'",
        f"grep -E 'Rss|Swap' /proc/{worker_pid}/smaps_rollup",
        "grep -E 'SwapUsed|SwapFree|SwapTotal' /proc/meminfo",
        "vmstat -s | grep -i swap",
    )
    wait_space("VmSwap > 0. Notice VmSize is unchanged — virtual space is just accounting. Press SPACE to free memory")

    # ══════════════════════════════════════════════════════════════════════════
    # STEP 4 — Cleanup: worker exits → all memory returned
    # ══════════════════════════════════════════════════════════════════════════
    step_header(4, "Cleanup — worker exits, memory and swap returned to OS")
    os.write(parent_go_w, b'\x03')    # let worker exit
    os.waitpid(worker_pid, 0)

    time.sleep(0.5)   # give kernel a moment to reclaim

    mi_after = read_meminfo()
    swap_used_after = kb_to_mb(mi_after.get('SwapTotal','0 kB')) - kb_to_mb(mi_after.get('SwapFree','0 kB'))
    mem_avail_after = kb_to_mb(mi_after.get('MemAvailable','0 kB'))

    print(f"\n  {c(GREEN,'✔')}  Worker exited — kernel reclaimed all physical pages and swap")
    print(f"  {c(DIM,'MemAvailable now:')}  {c(BOLD+GREEN, f'{mem_avail_after:.0f} MB')}")
    print(f"  {c(DIM,'SwapUsed now:    ')}  {c(BOLD+GREEN, f'{swap_used_after:.0f} MB')}  {c(DIM,'(back to ~0)')}")
    cmd_hint(
        "free -h",
        "vmstat -s | grep -i swap",
    )
    wait_space("Press SPACE for summary")

    os.close(child_done_r)
    os.close(parent_go_w)

# ══════════════════════════════════════════════════════════════════════════════
# Summary (parent only)
# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{SEP2}")
print(f"  {c(BOLD+GREEN,'DONE')}  — memory layer summary")
print(SEP2)
rows = [
    (CYAN,   'VmSize  (virtual)',  'Address space reserved via mmap/malloc — no RAM cost until touched'),
    (GREEN,  'VmRSS   (physical)', 'Pages in RAM — grows on page fault, shrinks when swapped or freed'),
    (ORANGE, 'VmSwap  (swap)',     'Pages evicted by kswapd when RAM is full — slow to access again'),
]
for col, name, desc in rows:
    print(f"  {c(BOLD+col, f'{name:<22}')}  {c(DIM, desc)}")
print(f"\n  {c(DIM,'Key insight:')}  {c(BOLD,'VmSize >= VmRSS + VmSwap')}  {c(DIM,'— virtual space is always the biggest number')}")
print(f"  {c(DIM,'Key insight:')}  {c(BOLD,'Swap is not free')}           {c(DIM,'— swapped pages are 100x slower to access than RAM')}")
print(f"{SEP2}\n")
