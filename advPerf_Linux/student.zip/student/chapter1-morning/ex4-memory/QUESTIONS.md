# 🐧 Exercise 4 — Virtual Memory, Physical Memory & Swap

> *Watch a process allocate 700 MB, fault in pages, and push the system into swap.*

---

1. We saw `VmSize` jump to 700 MB instantly after `mmap()`, but RAM didn't move.  
   Does that mean a process could `mmap` **terabytes** of virtual space with no cost?

2. What decides **which pages get evicted to swap** when RAM fills up?  
   Could the kernel swap out pages a process is actively using?

3. When the worker exited, `MemAvailable` jumped back up and `SwapUsed` dropped to ~0.  
   But swap is on **disk** — doesn't reading those pages back take time?
