# 🐧 Exercise 2 — Linux Process States

> *Put a real process into each state (R, S, D, T, Z) and observe it live.*

---

1. Can a process ever be in **two states at once** — for example `R` and `S`?

2. A **D-state process** can't be killed with `kill -9`. Does the system just hang forever if that I/O never completes?

3. We saw `systemd` reap the zombie when we killed the bad parent. What if **PID 1 itself had a bug** and never called `waitpid()`?
