#!/usr/bin/env python3
"""
EX2 - Linux Process States
===========================
Demonstrates all five Linux process states live.
Run as normal user — the D-state step drops page cache via sudo automatically.
"""
import os, sys, signal, subprocess, time
import tty, termios

# ── ANSI colours ──────────────────────────────────────────────────────────────
RESET   = "\033[0m"; BOLD  = "\033[1m"; DIM   = "\033[2m"
CYAN    = "\033[36m"; YELLOW = "\033[33m"; GREEN = "\033[32m"
RED     = "\033[31m"; MAGENTA = "\033[35m"; BLUE  = "\033[34m"
WHITE   = "\033[97m"; ORANGE = "\033[38;5;214m"

def c(color, text): return f"{color}{text}{RESET}"
SEP2 = c(BOLD + CYAN, "═" * 60)

STATE_COLORS = {
    'R': BOLD + GREEN,
    'S': BOLD + CYAN,
    'D': BOLD + ORANGE,
    'T': BOLD + YELLOW,
    'Z': BOLD + RED,
}

def wait_space(prompt=""):
    print(f"\n  {c(BOLD+YELLOW,'▶')}  {c(YELLOW, prompt or 'Press SPACE to continue...')}", end="", flush=True)
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        while True:
            ch = sys.stdin.read(1)
            if ch == ' ': break
            if ch in ('\x03', '\x04', 'q'):
                print(c(RED, "\n\nAborted.")); sys.exit(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
    print()

def step_header(n, title, state_char):
    col = STATE_COLORS.get(state_char, WHITE)
    print(f"\n{SEP2}")
    print(f"  {c(BOLD+CYAN, f'STEP {n}')}  {c(WHITE+BOLD, title)}  {c(col, f'[{state_char}]')}")
    print(SEP2)

def cmd_hint(*lines):
    print(f"\n  {c(BOLD+BLUE,'💡 Try in another terminal:')}")
    for l in lines: print(f"    {c(CYAN, l)}")

def read_state(pid):
    try:
        for line in open(f"/proc/{pid}/status"):
            if line.startswith("State:"):
                return line.split(":")[1].strip()
    except: return "gone"
    return "?"

def read_wchan(pid):
    try: return open(f"/proc/{pid}/wchan").read().strip()
    except: return "?"

def show_worker_state(pid):
    state = read_state(pid)
    wchan = read_wchan(pid)
    col   = STATE_COLORS.get(state[0], WHITE) if state and state[0] in STATE_COLORS else WHITE
    print(f"\n  {c(DIM,'Worker PID:')}  {c(BOLD+MAGENTA, str(pid))}")
    print(f"  {c(DIM,'State:     ')}  {c(col, state)}")
    print(f"  {c(DIM,'Waiting on:')}  {c(CYAN, wchan)}")

def cleanup(worker):
    try:
        worker.terminate()
        worker.wait(timeout=3)
    except Exception:
        try: worker.kill()
        except: pass

# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{SEP2}")
print(f"  {c(BOLD+WHITE, 'EX2 — Linux Process States')}")
print(f"  {c(DIM, 'We will demonstrate: R  S  D  T  Z')}")
print(SEP2)
print(f"\n  {c(DIM,'My PID:')}  {c(BOLD+MAGENTA, str(os.getpid()))}")
wait_space("Ready? Press SPACE to start with state R (Running)")

# ══════════════════════════════════════════════════════════════════════════════
# STEP 1 — R: Running / Executing
# ══════════════════════════════════════════════════════════════════════════════
step_header(1, "Running / Executing", "R")
print(f"""
  {c(BOLD,'What it means:')}
  {c(DIM,'  • R = on the CPU right now, OR in the run queue ready to go')}
  {c(DIM,'  • The scheduler picks R processes to run next')}
  {c(DIM,'  • A CPU-bound process (tight loop) stays in R continuously')}
""")

worker_r = subprocess.Popen(
    ['python3', '-c', 'while True: pass'],
    stderr=subprocess.DEVNULL
)
time.sleep(0.1)
show_worker_state(worker_r.pid)
cmd_hint(
    f"ps -o pid,ppid,stat,pcpu,comm -p {worker_r.pid}",
    f"cat /proc/{worker_r.pid}/status | grep State",
    f"top -p {worker_r.pid}",
)
wait_space("Observe CPU at 100% and R state. Press SPACE to move to state S")
cleanup(worker_r)

# ══════════════════════════════════════════════════════════════════════════════
# STEP 2 — S: Interruptible Sleep
# ══════════════════════════════════════════════════════════════════════════════
step_header(2, "Interruptible Sleep", "S")
print(f"""
  {c(BOLD,'What it means:')}
  {c(DIM,'  • Process is waiting for an event (timer, I/O, signal)')}
  {c(DIM,'  • Can be woken up by a signal at any time')}
  {c(DIM,'  • Most sleeping processes on the system are in S state')}
  {c(DIM,'  • Examples: sleep(), read() on a pipe, wait() for keyboard input')}
""")

worker_s = subprocess.Popen(
    ['python3', '-c', 'import time; time.sleep(9999)'],
    stderr=subprocess.DEVNULL
)
time.sleep(0.1)
show_worker_state(worker_s.pid)
cmd_hint(
    f"ps -o pid,ppid,stat,comm -p {worker_s.pid}",
    f"cat /proc/{worker_s.pid}/status | grep State",
    f"cat /proc/{worker_s.pid}/wchan",
)
wait_space("Look at wchan — the kernel function it is sleeping in. Press SPACE for state D")
cleanup(worker_s)

# ══════════════════════════════════════════════════════════════════════════════
# STEP 3 — D: Uninterruptible Sleep
# ══════════════════════════════════════════════════════════════════════════════
step_header(3, "Uninterruptible Sleep (Disk Sleep)", "D")
print(f"""
  {c(BOLD,'What it means:')}
  {c(DIM,'  • Process is waiting directly on hardware (disk, kernel lock)')}
  {c(DIM,'  • CANNOT be killed or interrupted — even kill -9 is ignored')}
  {c(DIM,'  • Disappears on its own when the I/O completes')}
  {c(DIM,'  • Triggered here: O_DIRECT reads on ext4 — bypasses page cache')}
  {c(DIM,'  • wchan shows blk_io_schedule — waiting in the block I/O layer')}
""")

# Prepare: create file on real ext4 (/mnt), drop page cache, read with O_DIRECT
dtest_path = "/mnt/ex2_dstate_test"
print(f"  {c(DIM,'Preparing 300 MB test file on ext4...')}", end='', flush=True)
r = subprocess.run(
    ['dd', 'if=/dev/zero', f'of={dtest_path}', 'bs=1M', 'count=300'],
    stderr=subprocess.DEVNULL
)
if r.returncode != 0:
    print(c(RED, ' FAILED — skipping D-state demo'))
    worker_d = None
    wait_space("Press SPACE to continue to state T")
else:
    print(c(GREEN, ' done'))
    subprocess.run(
        ['sudo', 'bash', '-c', 'echo 3 > /proc/sys/vm/drop_caches'],
        stderr=subprocess.DEVNULL
    )

    # bs=4096 satisfies O_DIRECT alignment; 50 MB of reads keeps it in D long enough
    worker_d = subprocess.Popen(
        ['dd', f'if={dtest_path}', 'of=/dev/null',
         'bs=4096', 'count=76800', 'iflag=direct'],   # 300 MB in 4 K blocks
        stderr=subprocess.PIPE
    )

    # Poll until we catch D state (up to 3 s) — D and R alternate per I/O block
    for _ in range(30):
        time.sleep(0.1)
        state = read_state(worker_d.pid)
        if 'D' in state:
            break
        if worker_d.poll() is not None:
            err = worker_d.stderr.read().decode().strip()
            print(c(RED, f"\n  dd exited early (rc={worker_d.returncode}): {err}"))
            break

    show_worker_state(worker_d.pid)
    cmd_hint(
        f"ps -o pid,ppid,stat,comm -p {worker_d.pid}",
        f"cat /proc/{worker_d.pid}/status | grep State",
        f"cat /proc/{worker_d.pid}/wchan",
        f"kill -9 {worker_d.pid}   # try it — D state ignores SIGKILL",
    )
    wait_space("Try kill -9 — it won't work while in D. Press SPACE to wait for I/O to complete")
    worker_d.wait()
    try: os.unlink(dtest_path)
    except: pass
    print(f"  {c(GREEN,'✔')}  I/O completed — worker exited normally")

wait_space("Press SPACE for state T (Stopped)")

# ══════════════════════════════════════════════════════════════════════════════
# STEP 4 — T: Stopped
# ══════════════════════════════════════════════════════════════════════════════
step_header(4, "Stopped", "T")
print(f"""
  {c(BOLD,'What it means:')}
  {c(DIM,'  • Process has been halted — not running, not waiting for I/O')}
  {c(DIM,'  • Triggered by SIGSTOP (or Ctrl-Z in a shell)')}
  {c(DIM,'  • Can ONLY be resumed by SIGCONT from another process')}
  {c(DIM,'  • SIGSTOP cannot be caught or ignored (unlike SIGTSTP)')}
  {c(DIM,'  • Used by: debuggers (gdb), job control, container runtimes')}
""")

worker_t = subprocess.Popen(
    ['python3', '-c', 'import time; time.sleep(9999)'],
    stderr=subprocess.DEVNULL
)
time.sleep(0.1)
print(f"  {c(DIM,'Before SIGSTOP:')}  {c(GREEN, read_state(worker_t.pid))}")
os.kill(worker_t.pid, signal.SIGSTOP)
time.sleep(0.1)
show_worker_state(worker_t.pid)
cmd_hint(
    f"ps -o pid,ppid,stat,comm -p {worker_t.pid}",
    f"cat /proc/{worker_t.pid}/status | grep State",
)
wait_space("Worker is frozen. Press SPACE to send SIGCONT and resume it")

os.kill(worker_t.pid, signal.SIGCONT)
time.sleep(0.1)
state_after = read_state(worker_t.pid)
print(f"\n  {c(GREEN,'✔')}  SIGCONT sent — new state: {c(BOLD+CYAN, state_after)}")
cmd_hint(f"ps -o pid,stat,comm -p {worker_t.pid}")
wait_space("Worker is back to S (sleeping). Press SPACE for state Z (Zombie)")
cleanup(worker_t)

# ══════════════════════════════════════════════════════════════════════════════
# STEP 5 — Z: Zombie
# ══════════════════════════════════════════════════════════════════════════════
step_header(5, "Zombie", "Z")
print(f"""
  {c(BOLD,'What it means:')}
  {c(DIM,'  • Process has exited but its parent has NOT called waitpid()')}
  {c(DIM,'  • The kernel keeps a minimal task_struct for the exit code')}
  {c(DIM,'  • Uses no CPU, no memory — but holds a PID slot')}
  {c(DIM,'  • Disappears when the parent reaps it with waitpid()')}
""")

# Fork an intermediate "bad parent" that creates a child and never reaps it
zombie_pid_r, zombie_pid_w = os.pipe()
go_r, go_w = os.pipe()

intermediate_pid = os.fork()
if intermediate_pid == 0:
    # Intermediate process: fork a child and never call waitpid()
    os.close(zombie_pid_r)
    os.close(go_w)
    child = os.fork()
    if child == 0:
        os.close(zombie_pid_w)
        os.close(go_r)
        os._exit(0)            # child exits immediately — becomes zombie
    os.write(zombie_pid_w, f"{child}\n".encode())
    os.close(zombie_pid_w)
    os.read(go_r, 1)           # wait until demo is done showing the zombie
    os._exit(0)

# Demo script (grandparent): read zombie child PID from intermediate
os.close(zombie_pid_w)
os.close(go_r)
zombie_child_pid = int(os.read(zombie_pid_r, 32).strip())
os.close(zombie_pid_r)

time.sleep(0.2)
state = read_state(zombie_child_pid)
col   = STATE_COLORS.get(state[0], WHITE) if state else WHITE
print(f"\n  {c(DIM,'Bad-parent PID:')}  {c(BOLD+MAGENTA, str(intermediate_pid))}")
print(f"  {c(DIM,'Zombie PID:    ')}  {c(BOLD+MAGENTA, str(zombie_child_pid))}")
print(f"  {c(DIM,'Zombie state:  ')}  {c(col, state)}")
cmd_hint(
    f"ps -o pid,ppid,stat,comm -p {intermediate_pid},{zombie_child_pid}",
    f"cat /proc/{zombie_child_pid}/status | grep State",
    f"ls /proc/{zombie_child_pid}/",
)
wait_space(f"PID {zombie_child_pid} is a zombie. Press SPACE to kill the parent (init will reap it)")

# Kill the bad parent — init/systemd adopts and reaps the zombie
os.write(go_w, b'\x01')
os.close(go_w)
os.waitpid(intermediate_pid, 0)
time.sleep(0.5)   # give init a moment to reap
print(f"\n  {c(GREEN,'✔')}  Parent exited → systemd adopted and reaped the zombie")
print(f"  {c(DIM, f'/proc/{zombie_child_pid} is now gone')}")
cmd_hint(f"ls /proc/{zombie_child_pid} 2>&1")
wait_space("Confirm zombie is gone. Press SPACE for summary")

# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{SEP2}")
print(f"  {c(BOLD+GREEN,'DONE')}  — Linux process state summary")
print(SEP2)
states_summary = [
    ('R', GREEN,   'Running / Executing',  'On CPU or in run queue — consuming CPU'),
    ('S', CYAN,    'Interruptible Sleep',  'Waiting for event — woken by signal or I/O'),
    ('D', ORANGE,  'Uninterruptible Sleep','Waiting on hardware — SIGKILL has no effect'),
    ('T', YELLOW,  'Stopped',              'Frozen by SIGSTOP — resumes only on SIGCONT'),
    ('Z', RED,     'Zombie',               'Exited, waiting for parent to call waitpid()'),
]
for char, col, name, desc in states_summary:
    print(f"  {c(BOLD+col, char)}  {c(BOLD, name):<30}  {c(DIM, desc)}")
print(f"{SEP2}\n")
