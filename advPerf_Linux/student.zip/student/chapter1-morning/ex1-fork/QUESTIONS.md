# 🐧 Exercise 1 — Process Creation via `fork()`

> *Observe how the kernel creates a child process and how Copy-on-Write (CoW) works.*

---

1. Why is `fork()` + `exec()` — the **"fork-exec model"** — the standard way to launch a new program on Linux?

2. What is the overhead of `fork()` if the parent has **2 GB** of mapped memory?

3. What happens to **file descriptors** after `fork()`? Are they shared between parent and child?

4. Why does a **zombie process** still appear in `ps` output even though it has finished executing?

5. What happens if the **parent exits before the child**? Who reaps the child?
