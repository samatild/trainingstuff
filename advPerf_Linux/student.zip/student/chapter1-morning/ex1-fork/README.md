# Exercise 1 — Process Creation via fork()

## Objective
Observe the Linux kernel create a child process via the `fork()` syscall and
understand **Copy-on-Write (CoW)** memory sharing between parent and child.

---

## Background

When a process calls `fork()`, the kernel:

1. Allocates a new `task_struct` (process descriptor)
2. Copies the parent's page-table entries — but marks all pages **read-only**
3. Returns **0** in the child, **child PID** in the parent
4. On the first write to a shared page → **page fault** → kernel copies the
   physical page for the writing process (Copy-on-Write)

This means `fork()` is **cheap**: no physical memory is copied upfront.

---

## Files

| File | Purpose |
|------|---------|
| `fork_demo.py` | Main demo — runs the full lifecycle |

---

## How to Run

**Terminal 1** — run the demo:
```bash
cd ~/perf-training/ex1-fork
python3 fork_demo.py
```

**Terminal 2** — observe as instructed by the script output.  
Use the commands below at each pause:

---

## Observation Commands

### Before fork — inspect the parent
```bash
# Process tree (parent only)
pstree -p $$

# Memory stats
ps -o pid,ppid,vsz,rss,comm -p <PARENT_PID>

# Detailed virtual memory
cat /proc/<PARENT_PID>/status | grep -E 'Vm|Pid|State'

# Count mapped regions
wc -l /proc/<PARENT_PID>/maps
```

### After fork — both processes alive
```bash
# See parent + child in tree
pstree -p <PARENT_PID>

# Compare RSS (resident set size) — CoW means child barely uses extra RAM
ps -o pid,ppid,vsz,rss,comm -p <PARENT_PID>,<CHILD_PID>

# smaps: detailed per-region memory accounting
cat /proc/<CHILD_PID>/smaps_rollup

# /proc/<pid>/maps: address space layout
cat /proc/<CHILD_PID>/maps
```

### Zombie state — before waitpid()
```bash
# Look for 'Z' in STAT column
ps aux | grep <CHILD_PID>

# Kernel still holds the task_struct
cat /proc/<CHILD_PID>/status | grep State

# Parent's fd table (child is not here — it exited cleanly)
ls /proc/<PARENT_PID>/fd
```

### After waitpid() — zombie reaped
```bash
# /proc entry is gone
ls /proc/<CHILD_PID>

# Parent is the only process left
pstree -p <PARENT_PID>
```

---

## What to Look For

| Observation | Expected result | Why |
|---|---|---|
| `VSZ` of child just after fork | ≈ same as parent | Page tables are copied |
| `RSS` of child just after fork | Much less than parent | CoW — pages not yet faulted in |
| Child's `RSS` after writing `data` | Increases | CoW fault caused physical copy |
| Child in `ps` after it exits but before `waitpid` | State = `Z` | Zombie: kernel keeps task_struct until parent reaps |
| `/proc/<child>` after `waitpid` | No such file | Kernel released all resources |

---

## Key Syscalls (strace)

You can watch the syscalls live:
```bash
strace -e trace=fork,clone,wait4,waitpid python3 fork_demo.py
```

---

## Discussion Questions

1. Why is `fork()` + `exec()` (the "fork-exec model") the standard way to
   launch a new program on Linux?
2. What is the overhead of `fork()` if the parent has 2 GB of mapped memory?
3. What happens to file descriptors after `fork()`? Are they shared?
4. Why does a zombie process still appear in `ps` output?
5. What happens if the parent exits before the child? Who reaps the child?
