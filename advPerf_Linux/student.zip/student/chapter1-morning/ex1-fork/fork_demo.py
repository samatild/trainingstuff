#!/usr/bin/env python3
"""
EX1 - How Linux creates a process via fork()
=============================================
Run this script and observe how the kernel creates a child process.
Open a second terminal for the observation commands shown on screen.
"""
import os
import sys
import tty
import termios

# ── ANSI colours ──────────────────────────────────────────────────────────────
RESET   = "\033[0m"
BOLD    = "\033[1m"
DIM     = "\033[2m"
CYAN    = "\033[36m"
YELLOW  = "\033[33m"
GREEN   = "\033[32m"
RED     = "\033[31m"
MAGENTA = "\033[35m"
BLUE    = "\033[34m"
WHITE   = "\033[97m"

def c(color, text):
    return f"{color}{text}{RESET}"

SEP2 = c(BOLD + CYAN, "═" * 60)

def wait_space(prompt=""):
    """Only call this from the PARENT — it owns the terminal."""
    msg = prompt or "Press  SPACE  to continue..."
    print(f"\n  {c(BOLD + YELLOW, '▶')}  {c(YELLOW, msg)}", end="", flush=True)
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        while True:
            ch = sys.stdin.read(1)
            if ch == ' ':
                break
            if ch in ('\x03', '\x04', 'q'):
                print(c(RED, "\n\nAborted."))
                sys.exit(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
    print()

def step_header(n, title):
    print(f"\n{SEP2}")
    print(f"  {c(BOLD + CYAN, f'STEP {n}')}  {c(WHITE + BOLD, title)}")
    print(SEP2)

def show_proc_status():
    pid = os.getpid()
    try:
        with open(f"/proc/{pid}/status") as f:
            status = {line.split(':')[0].strip(): line.split(':')[1].strip()
                      for line in f if ':' in line}
        print(f"  {c(DIM,'VmRSS  (resident set):')}  {c(GREEN, status.get('VmRSS',  'N/A'))}")
        print(f"  {c(DIM,'VmSize (virtual):     ')}  {c(GREEN, status.get('VmSize', 'N/A'))}")
        print(f"  {c(DIM,'Threads:              ')}  {c(GREEN, status.get('Threads','N/A'))}")
    except Exception as e:
        print(c(RED, f"  (could not read /proc status: {e})"))

def show_maps_summary():
    pid = os.getpid()
    try:
        with open(f"/proc/{pid}/maps") as f:
            n = sum(1 for _ in f)
        print(f"  {c(DIM, f'/proc/{pid}/maps')}  →  {c(GREEN, str(n))} mapped regions")
    except Exception as e:
        print(c(RED, f"  (could not read maps: {e})"))

def cmd_hint(*lines):
    print(f"\n  {c(BOLD + BLUE, '💡 Try in another terminal:')}")
    for l in lines:
        print(f"    {c(CYAN, l)}")

# ══════════════════════════════════════════════════════════════════════════════
# STEP 1 — parent only, no child yet
# ══════════════════════════════════════════════════════════════════════════════
step_header(1, "Before fork() — only the parent process exists")

print(f"\n  {c(DIM,'My PID: ')}  {c(BOLD + MAGENTA, str(os.getpid()))}")
print(f"  {c(DIM,'My PPID:')}  {c(MAGENTA, str(os.getppid()))}")
show_proc_status()
show_maps_summary()

# Allocate 4 MB — we'll watch CoW on this after fork
data = bytearray(4 * 1024 * 1024)
data[:] = b'\xAB' * len(data)
print(f"\n  {c(GREEN,'✔')}  Allocated {c(BOLD,'4 MB')} buffer  "
      f"(value={c(YELLOW,'0xAB')}, first byte: {c(YELLOW, f'0x{data[0]:02X}')})")

cmd_hint(
    f"ps -o pid,ppid,vsz,rss,comm -p {os.getpid()}",
    f"cat /proc/{os.getpid()}/status | grep -E 'Vm|Pid'",
)
wait_space("Inspect the parent, then press SPACE to call fork()")

# ══════════════════════════════════════════════════════════════════════════════
# Coordination pipes — set up BEFORE fork so both processes inherit them.
#
#   child_done:  child  → parent   (child signals it reached a checkpoint)
#   parent_go:   parent → child    (parent signals child to proceed)
#
# Only the PARENT calls wait_space(). The child never touches the terminal.
# ══════════════════════════════════════════════════════════════════════════════
child_done_r, child_done_w = os.pipe()
parent_go_r,  parent_go_w  = os.pipe()

step_header(2, "Calling fork()")
print(f"\n  {c(DIM, 'Executing:')}  {c(BOLD + CYAN, 'child_pid = os.fork()')}\n")
sys.stdout.flush()

child_pid = os.fork()   # ← THE SYSCALL

# ══════════════════════════════════════════════════════════════════════════════
if child_pid == 0:
    # ── CHILD PROCESS ────────────────────────────────────────────────────────
    # Child only writes to child_done and reads from parent_go.
    os.close(child_done_r)
    os.close(parent_go_w)

    step_header("C", "Inside the CHILD process  [fork() returned 0 here]")
    print(f"\n  {c(GREEN,'●')} {c(BOLD,'I am the child')}")
    print(f"  {c(DIM,'My PID:  ')}  {c(BOLD + MAGENTA, str(os.getpid()))}")
    print(f"  {c(DIM,'My PPID: ')}  {c(MAGENTA, str(os.getppid()))}  {c(DIM,'← parent PID')}")
    print(f"\n  {c(DIM,'data[0] before any write:')}  {c(YELLOW, f'0x{data[0]:02X}')}  "
          f"{c(DIM,'(CoW: sharing the same physical page as parent)')}")
    show_proc_status()
    sys.stdout.flush()

    # ── Checkpoint 1: child has printed initial state ─────────────────────
    os.write(child_done_w, b'\x01')   # notify parent
    os.read(parent_go_r, 1)           # wait: parent will press SPACE then signal us

    # ── CoW write ─────────────────────────────────────────────────────────
    print(f"\n  {c(BOLD + RED,'⚡ Writing to data[0]')}  "
          f"{c(DIM,'→ page fault → kernel copies the physical page for this process')}")
    data[0] = 0xCD
    print(f"  {c(DIM,'data[0] after  write:')}  {c(YELLOW, f'0x{data[0]:02X}')}  "
          f"{c(DIM,'(our private copy now)')}")
    print(f"  {c(DIM,'parent data[0] is still:')}  {c(YELLOW,'0xAB')}  "
          f"{c(DIM,'(different physical page — untouched)')}")
    show_proc_status()
    sys.stdout.flush()

    # ── Checkpoint 2: child has done the CoW write ────────────────────────
    os.write(child_done_w, b'\x02')   # notify parent
    os.read(parent_go_r, 1)           # wait: parent will press SPACE then signal us

    # ── Exit → become zombie ──────────────────────────────────────────────
    print(f"\n  {c(YELLOW,'[CHILD]')}  Calling {c(BOLD,'sys.exit(0)')}  →  "
          f"becoming a {c(RED + BOLD,'zombie')} until parent calls waitpid()\n")
    sys.stdout.flush()

    # Closing child_done_w sends EOF to parent — parent knows we're exiting
    os.close(child_done_w)
    os.close(parent_go_r)
    sys.exit(0)

else:
    # ── PARENT PROCESS ───────────────────────────────────────────────────────
    # Parent only reads from child_done and writes to parent_go.
    os.close(child_done_w)
    os.close(parent_go_r)

    # ── Wait for child to print its initial state (checkpoint 1) ─────────
    os.read(child_done_r, 1)

    step_header("P", "Back in the PARENT process  [fork() returned child PID here]")
    print(f"\n  {c(DIM,'fork() returned:')}  {c(BOLD + MAGENTA, str(child_pid))}  "
          f"{c(DIM,'← the child PID')}")
    print(f"  {c(DIM,'My own PID:    ')}  {c(BOLD + MAGENTA, str(os.getpid()))}")
    print(f"  {c(DIM,'data[0]:       ')}  {c(YELLOW, f'0x{data[0]:02X}')}  "
          f"{c(DIM,'(still 0xAB — CoW, not yet written)')}")
    show_proc_status()

    cmd_hint(
        f"pstree -p {os.getpid()}",
        f"ps -o pid,ppid,vsz,rss,comm -p {os.getpid()},{child_pid}",
        f"cat /proc/{child_pid}/smaps_rollup",
    )
    wait_space("Both processes alive — RSS is low (CoW). Press SPACE to trigger write in child")

    # ── Signal child to do the CoW write ─────────────────────────────────
    os.write(parent_go_w, b'\x01')

    # ── Wait for child to finish the write (checkpoint 2) ────────────────
    os.read(child_done_r, 1)

    print(f"\n  {c(DIM, 'Child wrote to its copy of data[0]. Compare RSS now:')}")
    cmd_hint(
        f"ps -o pid,ppid,vsz,rss,comm -p {os.getpid()},{child_pid}",
        f"cat /proc/{child_pid}/smaps_rollup",
    )
    wait_space("Note RSS increase on child after CoW fault. Press SPACE to let child exit")

    # ── Signal child to exit ──────────────────────────────────────────────
    os.write(parent_go_w, b'\x02')

    # ── Wait for child to exit — child closes child_done_w on exit → EOF ─
    os.read(child_done_r, 1)   # returns b'' (EOF) when child exits

    # Child is now a zombie — parent has NOT called waitpid() yet
    print(f"\n  {c(BOLD + RED,'⚠  Child exited — deliberately NOT calling waitpid()')}")
    print(f"  {c(DIM,'The child still exists in the process table as a zombie:')}")
    cmd_hint(
        f"ps -o pid,ppid,vsz,rss,stat,comm -p {os.getpid()},{child_pid}",
        f"cat /proc/{child_pid}/status 2>/dev/null | grep State",
    )
    wait_space(f"Look for stat='Z' for PID {child_pid}. Press SPACE to reap it")

    # ── Reap the zombie ───────────────────────────────────────────────────
    print(f"\n  {c(GREEN,'→')}  Calling {c(BOLD + CYAN, f'os.waitpid({child_pid}, 0)')}")
    waited_pid, wstatus = os.waitpid(child_pid, 0)
    exit_code = os.WEXITSTATUS(wstatus)
    print(f"  {c(GREEN,'✔')}  Reaped PID {c(BOLD, str(waited_pid))}, "
          f"exit code = {c(BOLD, str(exit_code))}")
    print(f"  {c(DIM, f'/proc/{waited_pid} is now gone — kernel released all resources')}")

    cmd_hint(
        f"ls /proc/{waited_pid} 2>&1",
        f"pstree -p {os.getpid()}",
    )
    wait_space("Confirm /proc entry is gone. Press SPACE for summary")

    os.close(child_done_r)
    os.close(parent_go_w)

# ══════════════════════════════════════════════════════════════════════════════
# Only the parent reaches here (child called sys.exit)
# ══════════════════════════════════════════════════════════════════════════════
print(f"\n{SEP2}")
print(f"  {c(BOLD + GREEN, 'DONE')}  — key concepts demonstrated")
print(SEP2)
points = [
    ("fork() clones the process",             "pages are shared (CoW) until written"),
    ("Child inherits parent's address space", "FDs, signal handlers, mappings"),
    ("fork() return value",                   "0 in child  /  child-PID in parent"),
    ("Un-reaped child",                       "becomes a zombie (Z state)"),
    ("waitpid()",                             "removes zombie, releases kernel resources"),
]
for i, (bold, dim) in enumerate(points, 1):
    print(f"  {c(CYAN, str(i)+'.')}  {c(BOLD, bold)}  {c(DIM, '— ' + dim)}")
print(f"{SEP2}\n")
